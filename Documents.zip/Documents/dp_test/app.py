from flask import Flask, render_template, request, g, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
db = SQLAlchemy(app)

# Модели базы данных
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    is_admin = db.Column(db.Boolean, default=False)

class Resource(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    data = db.Column(db.Text, nullable=True)

# Исключения
class UnauthorizedError(Exception):
    pass

class ValidationError(Exception):
    pass

class ResourceNotFoundError(Exception):
    pass

class BusinessLogicError(Exception):
    pass

# Функции для проверки и получения данных
def user_is_admin():
    return getattr(g, 'current_user', None) and g.current_user.is_admin

def validate_data(data):
    return 'name' in data and len(data['name']) > 0

def get_resource_by_id(resource_id):
    return Resource.query.get(resource_id)

def perform_business_logic():
    # Ваш бизнес-логика здесь
    pass

@app.before_request
def before_request():
    # Предположим, что первый пользователь - текущий
    g.current_user = User.query.first() 

@app.errorhandler(UnauthorizedError)
def handle_unauthorized_error(error):
    return render_template('unauthorized.html', message=str(error)), 401

@app.errorhandler(ValidationError)
def handle_validation_error(error):
    return render_template('validation_error.html', message=str(error)), 400

@app.errorhandler(ResourceNotFoundError)
def handle_resource_not_found_error(error):
    return render_template('resource_not_found.html', message=str(error)), 404

@app.errorhandler(BusinessLogicError)
def handle_business_logic_error(error):
    return render_template('business_logic_error.html', message=str(error)), 500

@app.errorhandler(Exception)
def handle_generic_exception(error):
    return render_template('generic_error.html', message=str(error)), 500

@app.route('/admin')
def admin():
    if not user_is_admin():
        raise UnauthorizedError("You do not have permission to access this page.")
    return render_template('admin.html')

@app.route('/submit', methods=['POST'])
def submit():
    data = request.form
    if not validate_data(data):
        raise ValidationError("Invalid data provided.")
    new_resource = Resource(name=data['name'], data=data.get('data'))
    db.session.add(new_resource)
    db.session.commit()
    return render_template('submit_success.html')

@app.route('/resource/<int:resource_id>')
def get_resource(resource_id):
    resource = get_resource_by_id(resource_id)
    if resource is None:
        raise ResourceNotFoundError(f"Resource with ID {resource_id} not found.")
    return render_template('resource.html', resource=resource)

# Маршрут для поиска и сортировки ресурсов с пагинацией
@app.route('/resources')
def resources():
    search_query = request.args.get('q', '')
    sort_by = request.args.get('sort_by', 'id')
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 10, type=int)

    query = Resource.query

    if search_query:
        query = query.filter(Resource.name.contains(search_query))

    if sort_by in ['id', 'name']:
        query = query.order_by(getattr(Resource, sort_by))

    pagination = query.paginate(page, per_page, error_out=False)
    resources = pagination.items

    return render_template('resources.html', resources=resources, pagination=pagination, search_query=search_query, sort_by=sort_by)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
