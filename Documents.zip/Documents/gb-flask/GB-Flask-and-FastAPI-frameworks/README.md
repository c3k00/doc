# GB-Flask-and-FastAPI-frameworks

Здесь будт сохранены решения с "семинаров" и дз

не забываем установить виртуальное окружение и установить фреймворки

python -m venv venv  # в Windows
(python3 -m venv venv   # в Linux или MacOS)

pip install Flask
