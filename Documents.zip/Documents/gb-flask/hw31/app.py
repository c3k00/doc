from flask import Flask, request, render_template, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import create_engine, Column, String, Integer
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.exc import IntegrityError
import hashlib

app = Flask(__name__)

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    first_name = Column(String)
    last_name = Column(String)
    email = Column(String, unique=True)
    password_hash = Column(String)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

engine = create_engine('sqlite:///users.db')
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
db = Session()

users = {}

@app.route('/', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        with app.app_context():
            first_name = request.form['first_name']
            last_name = request.form['last_name']
            email = request.form['email']
            password = request.form['password']

            try:
                new_user = User(first_name=first_name, last_name=last_name, email=email)
                new_user.set_password(generate_password_hash(password, method='pbkdf2:sha256', salt_length=16))
                db.add(new_user)
                db.commit()
                return redirect(url_for('registration_success'))
            except IntegrityError as e:
                db.rollback()
                return "User with this email already exists!"

    return render_template('register.html')

@app.route('/registration_success')
def registration_success():
    return "Registration successful!"

@app.route('/user_list')
def user_list():
    users_data = []
    for user in db.query(User):
        user_data = {
            'first_name': user.first_name,
            'last_name': user.last_name,
            'email': user.email,
            'password_hash': user.password_hash,
            'decrypted_password': 'Not available'
        }
        users_data.append(user_data)

    return render_template('user_list.html', users=users_data)

if __name__ == '__main__':
    app.run(debug=True)



