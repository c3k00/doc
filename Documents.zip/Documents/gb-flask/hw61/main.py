from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from database import engine, Base, database
from models import User, Product, Order
from schemas import UserCreate, User, ProductCreate, Product