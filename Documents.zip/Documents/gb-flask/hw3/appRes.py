from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    firstname = db.Column(db.String(50), nullable=False)
    lastname = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return f'<User {self.email}>'

@app.route('/users')
def show_users():
    with app.app_context():
        users = User.query.all()
        return render_template('users.html', users=users)

@app.route('/')
def register():
    # код для регистрации пользователей
    with app.app_context():
        if request.method == 'POST':
            firstname = request.form['firstname']
            lastname = request.form['lastname']
            email = request.form['email']
            password = request.form['password']

            hashed_password = generate_password_hash(password, method='pbkdf2:sha256', salt_length=16)

            new_user = User(firstname=firstname, lastname=lastname, email=email, password=hashed_password)
            db.session.add(new_user)
            db.session.commit()

            return redirect(url_for('register'))

        return render_template('register.html')

def verify_password(hashed_password, plaintext_password):
    return check_password_hash(hashed_password, plaintext_password)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        app.run(debug=True)